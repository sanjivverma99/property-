export class Location {
  id: number;
  city: string;

  constructor() {
    this.id = 0;
    this.city = '';
  }
}