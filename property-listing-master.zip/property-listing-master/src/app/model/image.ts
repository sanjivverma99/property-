export class Image {
    id: number;
    imageurl: string;
    size: number;

    constructor() {
        this.id = 0;
        this.imageurl = '';
        this.size = 0;
    }
    
}