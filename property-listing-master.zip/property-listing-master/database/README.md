## Property Listing - Database
This folder includes all of the databse code that the web application requires. This was accomplished with the help of **MySQL**.  

#### Either import or write down the sql query provided given in the `property-listing.sql` file in your MySQL application.

## Database Design
<p align="center">
  <img src="https://raw.githubusercontent.com/parithoshpoojary/property-listing/master/master/database/DB%20Design.JPG" />
</p>







































